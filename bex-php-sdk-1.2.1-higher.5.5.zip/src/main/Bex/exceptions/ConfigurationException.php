<?php

namespace Bex\exceptions;

use Exception;

class ConfigurationException extends Exception
{

}