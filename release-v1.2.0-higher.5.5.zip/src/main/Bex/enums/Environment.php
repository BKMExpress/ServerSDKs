<?php

namespace Bex\enums;

class Environment
{
    const DEV = "DEV";
    const LOCAL = "LOCAL";
    const SANDBOX = "SANDBOX";
    const PREPROD = "PREPROD";
    const PRODUCTION = "PRODUCTION";
}