<?php

namespace Bex\merchant\request\address;

class AddressType
{
    const INDIVIDUAL = "B";
    const CORPORATE = "K";
}

?>