<?php

namespace Bex\easy;

use Bex\config\BexPayment;
use Bex\exceptions\BexException;
use Bex\exceptions\ConfigurationException;
use Bex\merchant\request\Builder;
use Bex\merchant\request\InstallmentRequest;
use Bex\merchant\request\NonceRequest;
use Bex\merchant\response\BinAndInstallments;
use Bex\merchant\response\InstallmentsResponse;
use Bex\merchant\response\nonce\MerchantNonceResponse;
use Bex\merchant\response\TicketRefresh;
use Bex\merchant\security\EncryptionUtil;
use Bex\merchant\service\MerchantService;
use Logger;

class Bex
{
    private $config;
    private $isLoggedIn = false;
    private $merchantService;
    private $merchantLoginResponse;
    private $logger;

    private function __construct($environment, $merchantId, $merchantPrivateKey)
    {
        $this->logger = Logger::getLogger(__CLASS__);
        $this->config = Bex::init($environment, $merchantId, $merchantPrivateKey);
    }

    private static function init($environment, $merchantId, $merchantPrivateKey)
    {
        if (!isset($environment)) {
            throw new ConfigurationException("BKM Express Ayar dosyasında environment değeri bulunamadı ! Ipucu: 'environment' değeri 'DEV', 'LOCAL', 'SANDBOX', 'PRODUCTION' ortamlarından birini belirtmelidir !");
        }
        if (!isset($merchantId)) {
            throw new ConfigurationException("BKM Express Ayar dosyasında id değeri bulunamadı ! Ipucu: 'id' değeri BKM Expressden size tahsis edilen tekil belirteçtir.!");
        }
        if (!isset($merchantPrivateKey)) {
            throw new ConfigurationException("BKM Express Ayar dosyasında privateKey değeri bulunamadı ! Ipucu:  'DEV', 'LOCAL', 'SANDBOX', 'PRODUCTION' değerlerinden biri olmalıdır !");
        }

        return BexPayment::startBexPayment($environment, $merchantId, $merchantPrivateKey);
    }

    /**
     * @param $environment
     * @param $merchantId
     * @param $merchantPrivateKey
     *
     * @return Bex
     */
    public static function configure($environment, $merchantId, $merchantPrivateKey)
    {
        return new Bex($environment, $merchantId, $merchantPrivateKey);
    }

    public function refreshTicket($ticketArray)
    {
        $ticketResult = $this->createTicket($ticketArray);
        $ticketRefresh = new TicketRefresh(
            $ticketResult['id'],
            $ticketResult['path'],
            $ticketResult['token']
        );

        return array(
            'id' => $ticketRefresh->getId(),
            'path' => $ticketRefresh->getPath(),
            'token' => $ticketRefresh->getToken(),
        );
    }

    /**
     * {.
     *
     * }
     *
     * @param $ticketArray
     *
     * @return array
     *
     * @throws BexException
     */
    public function createTicket($ticketArray)
    {
        $this->login();
        $amount = (array_key_exists('amount', $ticketArray) ? $ticketArray['amount'] : null);
        if (empty($amount)) {
            throw new BexException('Toplam tutar zorunludur !');
        }
        $nonceUrl = (array_key_exists('nonceUrl', $ticketArray) ? $ticketArray['nonceUrl'] : null);
        if (empty($nonceUrl)) {
            throw new BexException('Nonce URL zorunludur !');
        }
        $builder = new Builder('payment');
        $builder->setAmount($amount);
        $builder->setInstallmentUrl((array_key_exists('installmentUrl', $ticketArray) ? $ticketArray['installmentUrl'] : null));
        $builder->setNonceUrl($nonceUrl);
        $builder->setCampaignCode((array_key_exists('campaignCode', $ticketArray) ? $ticketArray['campaignCode'] : null));
        $builder->setOrderId((array_key_exists('orderId', $ticketArray) ? $ticketArray['orderId'] : null));
        $builder->setTckn((array_key_exists('tckn', $ticketArray) ? $ticketArray['tckn'] : null));
        $builder->setMsisdn((array_key_exists('msisdn', $ticketArray) ? $ticketArray['msisdn'] : null));
        $builder->setAddress((array_key_exists('address', $ticketArray) ? $ticketArray['address'] : null));
        $builder->setAgreementUrl((array_key_exists('agreementUrl', $ticketArray) ? $ticketArray['agreementUrl'] : null));

        $ticketResponse = $this->merchantService->oneTimeTicketWithBuilder(
            $this->merchantLoginResponse->getToken(),
            $builder
        );

        return array(
            'id' => $ticketResponse->getTicketShortId(),
            'path' => $ticketResponse->getTicketPath(),
            'token' => $ticketResponse->getTicketToken(),
        );
    }

    private function login()
    {
        if (!$this->isLoggedIn) {
            $this->merchantService = new MerchantService($this->config);
            $this->merchantLoginResponse = $this->merchantService->login();
            $this->isLoggedIn = $this->merchantLoginResponse->getResult();
        }
        if (!$this->isLoggedIn) {
            $message = $this->merchantLoginResponse->getMessage();
            throw new BexException($message);
        }
    }

    public function queryTicket($ticketPath)
    {
        $this->login();
        return $this->merchantService->queryTicket($ticketPath);
    }

    public function installments(callable $callback)
    {
        //DONEN RESPONSE UMUZ APPLICATION/JSON FORMATINDA OLMALIDIR.
        header('Content-type: application/json');
        // REQUEST DATASINI ALDIGIMIZ YER
        $data = json_decode(file_get_contents('php://input'), true);
        $this->logger->trace("Installment Service Received Data : ".json_encode($data, JSON_PRETTY_PRINT));
        $installmentResponse = new InstallmentsResponse();
        if (empty($data)) {
            throw new BexException('Request body can not get !');
        }
        //GELEN REQUEST DATASI ILE OBJEMIZI OLUSTRUYORUZ.
        $installmentRequest = new InstallmentRequest($data['bin'], $data['totalAmount'], $data['ticketId'], $data['signature']);
        //REQUESTTE GELEN SIGNATURE DEGERINI EGER UZERINDE OYNANMIS ISE HATALI OLARAK DONUYORUZ.
        //KONTROLLERI ENCRYPTION UTIL SINIFINDA YAPILMAKTADIR.
        if (!EncryptionUtil::verifyBexSign(
            $installmentRequest->getTicketId(),
            $installmentRequest->getSignature()
        )
        ) {
            // SIGN ERROR
            exit(json_encode(array('data' => null, 'status' => 'fail', 'error' => 'Signature verification failed.')));
        }
        try {
            //REQUESTTEN GELEN BIN IN 0. ELEMENTINDE BIN AND BANK I DEGERE ATIYORUZ.
            $binAndBank = $installmentRequest->getBinNo()[0];
            //BANKA KODUNU EXPLODEDARR E ATIYORUZ.
            $explodedArr = explode('@', $binAndBank);
            // get installments
            $installments = $callback(array(
                'ticketId' => $installmentRequest->getTicketId(),
                'totalAmount' => $installmentRequest->getTotalAmount(),
                'bin' => $explodedArr[0],
                'bank' => $explodedArr[1],
            ));
            //DONECEGIMIZ GENEL RESPONSE TIPI
            $binAndInstallments = new BinAndInstallments();
            $installmentResponse->setInstallments($installments);
            $installmentResponse->setStatus('ok');
            $installmentResponse->setBin($explodedArr[0]);
            $returnArray = array();
            $returnArray[$installmentResponse->getBin()] = $installmentResponse->getInstallments();
            $binAndInstallments->setInstallments($returnArray);
            exit(json_encode(array('data' => $binAndInstallments, 'status' => 'ok', 'error' => '')));
        } catch (\Exception $exception) {
            exit(json_encode(array('data' => null, 'status' => 'fail', 'error' => $exception->getMessage())));
        }
    }

    public function approve(callable $callback)
    {
        $this->login();
        //NULL CHECK
        $data = $this->takeDataAndRespond();
        if (null != $data) { // Data is ok.
            $this->logger->trace("Nonce Service Received Data : ".json_encode($data, JSON_PRETTY_PRINT));
            //NONCE REQUEST I SETLIYORUZ.
            //NONCE REQUESTTEN BIZE ASAGIDAKI GIBI SETLENMIS DATALAR GELMEKTEDIR.
            $nonceRequest = new NonceRequest(
                (array_key_exists('id', $data) ? $data['id'] : null),
                (array_key_exists('path', $data) ? $data['path'] : null),
                (array_key_exists('issuer', $data) ? $data['issuer'] : null),
                (array_key_exists('approver', $data) ? $data['approver'] : null),
                (array_key_exists('token', $data) ? $data['token'] : null),
                (array_key_exists('signature', $data) ? $data['signature'] : null),
                (array_key_exists('reply', $data) ? $data['reply'] : null),
                (array_key_exists('reply', $data) ? $data['reply']['hash'] : null),
                (array_key_exists('reply', $data) ? $data['reply']['tcknMatch'] : null),
                (array_key_exists('reply', $data) ? $data['reply']['msisdnMatch'] : null)
            );
            //ILK RESPONSE U DONDUKDEN SONRA MICRO SERVIS  2. RESPONSU DONECEGIZ.
            //NONCE RESPONSE ORNEGI
            $merchantNonceResponse = new MerchantNonceResponse();
            
            //SIGNATURE KONTROLUNU YAPIYORUZ.
            //EGER SIGNATURE DOGRU ISE ISTENILEN RESPONSU AYARLIYORUZ.
            //BASARILI RESPONSE ORNEGI
            //SIGNATURE KONTROLUNDE TICKET ID OLARAK NONCE REQUESTTEN GELEN TICKET ID ILE KONTROL ETMEK GEREKMEKTEDIR
            //KONTROL EDILECEK OLAN SIGNATURE DA NONCE DAN GELMEKTEDIR.
            if (EncryptionUtil::verifyBexSign($nonceRequest->getTicketId(), $nonceRequest->getSignature())) {
                //DONULMESI GEREKEN RESPONSE'UN KOD ORNEGI.
                $merchantNonceResponse->setResult($callback($data));
                $merchantNonceResponse->setNonce($nonceRequest->getToken());
                $merchantNonceResponse->setId($nonceRequest->getPath());
                //NONCE RESPONSU SETLEDIKDEN SONRA MERCHANT SERVICE DEN SENDNONCERESPONCE SERVISINI CAGIRIYORUZ.
                //PARAMETRELER SIRASIYLA
                //1-)SETLEDIGIMIZ RESPONSE SINIFI
                //2-)MERCHANTLOGINDEN DONEN PATH
                //3-)NONCE REQUESTTEN GELEN PATH
                //4-)MERCHANT LOGINDEN GELEN CONNECTION TOKEN
                //5-)NONCE REQUESTTEN GELEN TOKEN
                return $this->merchantService->sendNonceResponse(
                    $merchantNonceResponse,
                    $this->merchantLoginResponse->getPath(),
                    $nonceRequest->getPath(),
                    $this->merchantLoginResponse->getConnectionToken(),
                    $nonceRequest->getToken()
                );
            } else {
                //BASARISIZ RESPONSE ORNEGI
                //BURADA RESULT FALSE OLARAK SETLENIR VE MESSAGE SETLENIR.
                $merchantNonceResponse->setResult(false);
                $merchantNonceResponse->setNonce($nonceRequest->getToken());
                $merchantNonceResponse->setId($nonceRequest->getPath());
                $merchantNonceResponse->setMessage('Signature verification failed');
                return $this->merchantService->sendNonceResponse(
                    $merchantNonceResponse,
                    $this->merchantLoginResponse->getPath(),
                    $nonceRequest->getPath(),
                    $this->merchantLoginResponse->getConnectionToken(),
                    $nonceRequest->getToken()
                );
            }
        }
    }

    /**
     * respondOK.
     */
    protected function takeDataAndRespond()
    {
        //ISTEKDEN GELEN REQUESTI ALIYORUZ.
        $data = json_decode(file_get_contents('php://input'), true);
        //NULL CHECK
        if (null != $data) {
            //DONULMESI GEREKEN RESPONSE ORNEGI JSON FORMATINDA OLMALIDIR.
            header('Content-type: application/json');
            // NONCE ILK RESPONSE
            //ILK RESPONSE UN FORMATINA DIKKAT EDILMELIDIR.
            
            // Turn on output buffering
            // There will be no output until you "flush" or echo the buffer's contents
            ob_start();
            echo json_encode(array(
                "result" => "ok",
                "data" => "ok"
            ));
            $size = ob_get_length();
            // Disable compression (in case content length is compressed).
            header("Content-Encoding: none");
            header($_SERVER["SERVER_PROTOCOL"] . " 202 Accepted");
            header("Status: 202 Accepted");
            header("Content-Length: {$size}");
            header("Connection: close");
            // Put all of the above ouptut into a variable
            // This has to be before you "clean" the buffer
            $content = ob_get_contents();
            // Erase the buffer in case we want to use it for something else later
            ob_end_clean();
            // Flush the buffer
            if (false !== ob_get_length())
                ob_end_flush();
            // All of the data that was in the buffer is now in $content
            echo $content;
            ignore_user_abort(true);
            set_time_limit(0);
            flush();
            sleep(3);
            
            // check if fastcgi_finish_request is callable
            if (is_callable('fastcgi_finish_request')) {
                /*
                 * This works in Nginx but the next approach not
                 */
                session_write_close();
                fastcgi_finish_request();
            }
            
            if (!isset($data['reply']['deliveryAddress'])) {
                $data['reply']['deliveryAddress'] = null;
            }
            if (! isset($data['reply']['billingAddress'])) {
                $data['reply']['billingAddress'] = null;
            }
            if (! isset($data['reply']['tcknMatch'])) {
                $data['reply']['tcknMatch'] = false;
            }
            if (! isset($data['reply']['msisdnMatch'])) {
                $data['reply']['msisdnMatch'] = false;
            }

            return $data;
        }
        return null;
    }

    /**
     *
     * @param
     *            $orderData
     * @return \Bex\merchant\response\RefundResponse
     * @throws BexException
     * @throws \Bex\exceptions\MerchantServiceException
     */
    public function refund($refundRequestData)
    {
        $refundRequest = (new \Bex\merchant\request\RefundRequest())
        ->setUniqueReferans($refundRequestData['uniqueReferans'])
        ->setAmount($refundRequestData['amount'])
        ->setTransactionToken($refundRequestData['ticketId'])
        ->setMerchantId(MERCHANT_ID)
        ->setRequestType(intval($refundRequestData['requestType']))
        ->setCurrency(949)
        ->setTs(date('ymd-h:i:s'))
        ;
        
        $this->login();
        return $this->merchantService->refund($refundRequest, $this->merchantLoginResponse->getToken());
    }
    
    public function transactionList()
    {
        $transactionListRequest = new \Bex\merchant\request\transactions\TransactionListRequest(
            MERCHANT_ID,
            (new \DateTime('-1 week'))->format('Y-m-d H:i'),
            (new \DateTime())->format('Y-m-d H:i')
            );
        
        $this->login();
        return $this->merchantService->transactionList($transactionListRequest, $this->merchantLoginResponse->getToken());
    }
    
    public function transactionDetail($orderId, $ticket)
    {
        $transactionDetailRequest = new \Bex\merchant\request\transactions\TransactionDetailRequest(
            MERCHANT_ID,
            $ticket,
            $orderId
            );
        
        $this->login();
        return $this->merchantService->transactionDetail($transactionDetailRequest, $this->merchantLoginResponse->getToken());
    }

    public function getConfig()
    {
        return $this->config;
    }

    public function getBaseJs()
    {
        return $this->config->getBexApiConfiguration()->getBaseJs();
    }

    public function getBaseUrl()
    {
        return $this->config->getBexApiConfiguration()->getBaseUrl();
    }
}
