<?php

namespace Bex\exceptions;

use Exception;

class BexException extends Exception
{
}
