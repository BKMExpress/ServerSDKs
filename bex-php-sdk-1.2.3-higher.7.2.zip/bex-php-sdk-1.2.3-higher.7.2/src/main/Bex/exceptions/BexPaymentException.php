<?php

namespace Bex\exceptions;

use Exception;

class BexPaymentException extends Exception
{
}
