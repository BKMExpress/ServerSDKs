<?php

require_once __DIR__.'/config.php';
require_once __DIR__.'/BexUtil.php';

Logger::getLogger('refund_php')->trace('HTTP REQUEST TO => '.__FILE__);

$request_body = json_decode(file_get_contents('php://input'));

$refundRequestData = array();
$refundRequestData['amount'] = $request_body->amount;
$refundRequestData['ticketId'] = $request_body->ticketId;
$refundRequestData['requestType'] = $request_body->requestType;
$refundRequestData['uniqueReferans'] = BexUtil::randomToken(24);

$ticketResponse = $bex->refund($refundRequestData);

exit(json_encode([
    'response' => $ticketResponse,
]));
