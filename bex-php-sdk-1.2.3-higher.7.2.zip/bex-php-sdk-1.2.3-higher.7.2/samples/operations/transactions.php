<?php

require_once __DIR__.'/config.php';
require_once __DIR__.'/BexUtil.php';

Logger::getLogger('transactions.php_php')->trace('HTTP REQUEST TO => '.__FILE__);

$request_body = json_decode(file_get_contents('php://input'));

$table = BexUtil::readJsonFile(DATA_FILE_NAME);

$orderId = @$_GET['orderId'];
$ticket = @$_GET['ticket'];

if ($orderId && $ticket) {
    $ticketResponse = $bex->transactionDetail($orderId, $ticket);
} else {
    $ticketResponse = $bex->transactionList();
}

exit(json_encode([
    'status' => 'SUCCESS',
    'response' => $ticketResponse,
]));
