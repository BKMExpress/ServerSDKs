<?php

require_once __DIR__.'/config.php';
require_once __DIR__.'/BexUtil.php';

Logger::getLogger('nonce_php')->trace('HTTP REQUEST TO => '.__FILE__);

function writeDb($orderId, $status, $message, $error = false, $detail = null)
{
    $table = BexUtil::readJsonFile(DATA_FILE_NAME);
    $orderData = $table[$orderId];
    if (!$orderData) {
        throw new Exception("Order not found by $orderId orderId");
    }
    $orderData['status'] = $status;
    $orderData['message'] = $message;
    $orderData['error'] = $error;
    $orderData['detail'] = $detail;
    $table[$orderId] = $orderData;

    Logger::getLogger('nonce_php')->trace(__METHOD__, (array) $orderData);
    BexUtil::writeJsonFile(DATA_FILE_NAME, $table);
}

$orderId = null;

try {
    $nonceResult = $bex->approve(function ($data) {
        global $orderId;
        $orderId = $data['reply']['orderId'];

        $table = BexUtil::readJsonFile(DATA_FILE_NAME);

        $orderData = &$table[$orderId];
        // $orderData["orderId"] == $data["reply"]["orderId"] // ticket oluştururken orderId gönderimi yaparsanız nonce'ta sisteminizdeki orderId ile kontrol sağlayabilirsiniz.
        if ($orderData && $orderData['amount'] == $data['reply']['totalAmount']) {
            $orderData['status'] = 'Approved';
            $orderData['message'] = 'Ödeme onaylandı';
            Logger::getLogger('nonce_php')->trace($data);
            $orderData['transactionToken'] = $data['id'];
            BexUtil::writeJsonFile(DATA_FILE_NAME, $table);

            return true;
        }
        $orderData['error'] = true;
        $orderData['status'] = 'Not_Approved';
        $orderData['message'] = 'Ödeme reddedildi !';
        BexUtil::writeJsonFile(DATA_FILE_NAME, $table);

        return false;
    });
    Logger::getLogger('nonce_php')->trace(__FILE__.' - nonceResult::getPaymentPurchased => '. ((int) $nonceResult->getPaymentPurchased()));
    Logger::getLogger('nonce_php')->trace(__FILE__.' - nonceResult => '. serialize($nonceResult));
    if ($nonceResult->getPaymentPurchased()) { // payment is ok.
        writeDb($orderId, 'SUCCESS', 'Ödeme tamamlandı');
    } else {
        writeDb($orderId, 'FAILED', 'Ödeme yapılamadı !', true);
    }
} catch (\GuzzleHttp\Exception\ClientException $exception) {
    Logger::getLogger('nonce_php')->error(__FILE__.' - EXCEPTION => '. $exception->getRequest()->getBody()->getContents());
    Logger::getLogger('nonce_php')->error(__FILE__.' - EXCEPTION => '. $exception->getMessage());
    writeDb($orderId, $exception->getCode(), 'Ödeme yapılamadı !', true, $exception->getMessage());
} catch (Exception $exception) {
    Logger::getLogger('nonce_php')->error(__FILE__.' - EXCEPTION => '. $exception->getMessage());
    writeDb($orderId, $exception->getCode(), 'Ödeme yapılamadı !', true, $exception->getMessage());
}
