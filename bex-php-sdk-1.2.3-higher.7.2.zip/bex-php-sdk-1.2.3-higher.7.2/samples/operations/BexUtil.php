<?php

use Bex\merchant\security\EncryptionUtil;
use Bex\util\MoneyUtils;

class BexUtil
{
    public static function readJsonFile($jsonFile)
    {
        return json_decode(file_get_contents($jsonFile), true);
    }

    public static function writeJsonFile($jsonFile, $jsonData)
    {
        return file_put_contents($jsonFile, utf8_encode(json_encode($jsonData, JSON_PRETTY_PRINT)));
    }

    public static function formatTurkishLira($amount)
    {
        return MoneyUtils::formatTurkishLira($amount);
    }

    public static function toFloat($amount)
    {
        return MoneyUtils::toFloat($amount);
    }

    public static function vposConfig($vposJsonFile, $bank)
    {
        $vposConfigs = json_decode(file_get_contents($vposJsonFile), true);
        $vposConfig = $vposConfigs[$bank];
        if (null == $vposConfig) {
            throw new Exception("$bank not found in $vposJsonFile vpos configuration file");
        }

        return EncryptionUtil::encryptWithBex(json_encode($vposConfig));
    }
    
    public static function randomToken($length = 24)
    {
        if (!isset($length) || intval($length) <= 8 ) {
            $length = 24;
        }
        $length = intval($length/2);
        
        if (function_exists('random_bytes')) {
            return bin2hex(random_bytes($length));
        }
        if (function_exists('mcrypt_create_iv')) {
            return bin2hex(mcrypt_create_iv($length, MCRYPT_DEV_URANDOM));
        }
        if (function_exists('openssl_random_pseudo_bytes')) {
            return bin2hex(openssl_random_pseudo_bytes($length));
        }
    }
}

$util = new BexUtil();
