<?php

require_once __DIR__.'/config.php';
require_once __DIR__.'/BexUtil.php';

Logger::getLogger('installment_php')->trace('HTTP REQUEST TO => '.__FILE__);

$userData = BexUtil::readJsonFile(DATA_FILE_NAME);

$bex->installments(function ($installmentArray) {
    $installments = [];

    $totalAmountStr = $installmentArray['totalAmount'];

    $posConfig = BexUtil::vposConfig('vpos.json', $installmentArray['bank']);

    // iki taksit yapalım
    $installmentAmount = BexUtil::formatTurkishLira(
        BexUtil::toFloat($totalAmountStr) / 1.0
    );
    // 1.ci taksiti ayarlayalım.
    $installments[] = [
        'numberOfInstallment' => 1,
        'installmentAmount' => $installmentAmount,
        'totalAmount' => $totalAmountStr,
        'vposConfig' => $posConfig,
    ];

    // iki taksit yapalım
    $installmentAmount = BexUtil::formatTurkishLira(
        BexUtil::toFloat($totalAmountStr) / 2.0
    );

    // 2. Taksiti ayarlayalım.
    $installments[] = [
        'numberOfInstallment' => 2,
        'installmentAmount' => $installmentAmount,
        'totalAmount' => $totalAmountStr,
        'vposConfig' => $posConfig,
    ];
    // Taksitleri bir array olarak dönelim.
    return $installments;
});
