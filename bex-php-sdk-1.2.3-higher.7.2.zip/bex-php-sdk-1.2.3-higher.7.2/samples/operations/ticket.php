<?php

require_once __DIR__.'/config.php';
require_once __DIR__.'/BexUtil.php';

Logger::getLogger('ticket_php')->trace('HTTP REQUEST TO => '.__FILE__);

$request_body = json_decode(file_get_contents('php://input'));

$table = BexUtil::readJsonFile(DATA_FILE_NAME);
$orderId = $request_body->orderId;

$table[$orderId] = array(
    'amount' => $request_body->amount,
    'error' => false,
    'orderId' => $request_body->orderId,
    'status' => 'STARTED',
    'message' => 'Ödeme aşamasına geçildi.',
);

BexUtil::writeJsonFile(DATA_FILE_NAME, $table);

$type = $request_body->type;

$data = $table[$request_body->orderId];

$nonceUrl = "$serverUrl/operations/nonce.php";
$installmentUrl = "$serverUrl/operations/installment.php";
$agreementUrl = "$serverUrl/operations/agreement.php";

/**
 * Ticket Input
 * {
 *  "amount": "1000,54",  // zorunlu (Ödeme Tutarı)
 *  "installmentUrl": "https://isyeri.com/installment",  // opsiyonel ("SIZIN SERVER'INIZDA TAKSITLERI SORGULAMAK ICIN BIR URL")
 *  "nonceUrl": "https://isyeri.com/nonce",  // zorunlu ("SIPARISIN UYGUNLUGUNUN KONTROL EDILMESI ICIN URL")
 *  "campaignCode": "BKM1234",   // opsiyonel (Kampanya Kodu)
 *  "orderId": "123456", // opsiyonel. ( Sipariş Numarası - Her Ticket isteği için farklı bir değer içermeli)
 *  "tckn": {  // opsiyonel (number => "TC Kimlik Numarası", check => "BKM Express içerisinde kontrol edilsin mi")
 *    "no": "1000,540000146",
 *    "check": true
 *  },
 *  "msisdn": { // opsiyonel ('no' => "cep telefonu numarası", 'check' => "BKM Express içerisinde kontrol edilsin mi")
 *      "no": "5051234567",
 *      "check": true
 *  },
 *  "address": true,  // opsiyonel (adres entegrasyonları kullananlar için)
 *  "agreementUrl: "https://isyeri.com/agreement" // opsiyonel ("Mesafeli satış ve ön bilgilendirme formu için sizin sitenize yönlenecek url") adres entegrasyonları için zorunlu
 * }.
 */
$ticketData = [
    'amount' => $data['amount'],
    'nonceUrl' => $nonceUrl,
    'orderId' => $request_body->orderId,
];

if ('payment_with_installment' === $type) {
    $ticketData['installmentUrl'] = $installmentUrl;
}

if ('payment_with_address' === $type) {
    $ticketData['address'] = true;
    $ticketData['agreementUrl'] = $agreementUrl;
}

$ticketResponse = $bex->createTicket($ticketData);

exit(json_encode([
    'config' => array(
        'baseJs' => $bex->getBaseJs(),
        'baseUrl' => $bex->getBaseUrl(),
    ),
    'response' => $ticketResponse,
]));
