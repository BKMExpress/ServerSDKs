<?php

require_once __DIR__.'/config.php';
require_once __DIR__.'/BexUtil.php';

$request_body = json_decode(file_get_contents('php://input'));

$table = BexUtil::readJsonFile(DATA_FILE_NAME);
$orderData = $table[$request_body->orderId];
$orderData['orderId'] = $request_body->orderId;
exit(json_encode($orderData, true));

?>
