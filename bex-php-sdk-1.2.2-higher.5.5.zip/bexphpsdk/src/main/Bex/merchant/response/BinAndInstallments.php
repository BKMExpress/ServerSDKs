<?php

namespace Bex\merchant\response;

class BinAndInstallments
{
    public $installments;

    /**
     * @return mixed
     */
    public function getInstallments()
    {
        return $this->installments;
    }

    /**
     * @param mixed $installments
     */
    public function setInstallments($installments)
    {
        $this->installments = $installments;
    }
}
