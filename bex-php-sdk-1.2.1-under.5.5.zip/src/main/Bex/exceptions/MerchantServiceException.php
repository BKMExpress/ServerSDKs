<?php

namespace Bex\exceptions;

use Exception;

class MerchantServiceException extends Exception
{

}