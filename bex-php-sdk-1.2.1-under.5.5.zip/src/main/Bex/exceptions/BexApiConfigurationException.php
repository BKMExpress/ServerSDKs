<?php

namespace Bex\exceptions;

use Exception;

class BexApiConfigurationException extends Exception
{

}