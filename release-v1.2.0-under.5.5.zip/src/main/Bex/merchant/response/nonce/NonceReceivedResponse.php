<?php
namespace Bex\merchant\response\nonce;

class NonceReceivedResponse
{
    const status = "OK";


}